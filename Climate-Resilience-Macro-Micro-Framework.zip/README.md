# Climate Resilience: Macro–Micro Integrated Framework

This repository contains all scripts, data, and outputs associated with the paper:

> *Integrating Macro–Micro Frameworks for Climate Resilience Assessment in Low-Income Countries*  
> Submitted to **PLOS Climate**, 2025.

## 🔧 Contents
- `scripts/` — dynamic panel (GMM) and spatial interpolation code  
- `data/` — synthetic and field datasets (macro panel and Uganda micro points)  
- `outputs/` — regression tables, RAS parameters, spatial maps  
- `figures/` — all in-text and appendix figures in PNG format  
- `validation/` — diagnostics, cross-validation, and reproducibility tests  

## 📦 Reproducibility
All results can be regenerated using:
```bash
python scripts/run_validation.py
```
Outputs reproduce Tables 1–A8 and Figures 1–A7 in the manuscript.

## 📜 License
MIT License.

## 📬 Citation
If you use this repository, please cite:
> Author(s). *Integrating Macro–Micro Frameworks for Climate Resilience Assessment in Low-Income Countries.* PLOS Climate, 2025.

